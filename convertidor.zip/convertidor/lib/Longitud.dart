import 'package:flutter/material.dart';

class Longitud extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LongitudState();
  }
}

class LongitudState extends State<Longitud>{

  TextEditingController MCController = TextEditingController();
  TextEditingController MPController = TextEditingController();
  TextEditingController YMController = TextEditingController();
  TextEditingController PCController = TextEditingController();

  double resultado;
  double resultado2;
  double resultado3;
  double resultado4;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(

        appBar: AppBar(
          title: Text('LONGITUD'),
        ),
        body: ListView(
          children: <Widget>[
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Metro a Centímetro'),
                    //subtitle: Text('Music by Julie Gable. Lyrics by Sidney Stein.'),
                  ),
                  TextField(
                      controller: MCController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado = (double.parse(MCController.text)) * (100) ;
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado CM"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Metros a Pies'),
                  ),
                  TextField(
                      controller: MPController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado2 = (double.parse(MPController.text)) * (3.281);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado2 Ft"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Yarda a Metro'),
                  ),
                  TextField(
                      controller: YMController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado3 = (double.parse(YMController.text)) / (1.094);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado3 M"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Pulgada a Centímetro'),
                  ),
                  TextField(
                      controller: PCController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado4 = (double.parse(PCController.text)) * (2.54);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado4 CM"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        )
    );
  }
}