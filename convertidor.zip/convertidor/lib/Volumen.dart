import 'package:flutter/material.dart';

class Volumen extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return VolumenState();
  }
}

class VolumenState extends State<Volumen>{

  TextEditingController MLController = TextEditingController();
  TextEditingController GLController = TextEditingController();
  TextEditingController OLController = TextEditingController();
  TextEditingController PLController = TextEditingController();

  double resultado;
  double resultado2;
  double resultado3;
  double resultado4;


  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(

        appBar: AppBar(
          title: Text('VOLUMEN'),
        ),
        body: ListView(
          children: <Widget>[
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Mililítro a Litro'),
                    //subtitle: Text('Music by Julie Gable. Lyrics by Sidney Stein.'),
                  ),
                  TextField(
                      controller: MLController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado = (double.parse(MLController.text)) /(1000) ;
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado L"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Galón estadounidense a Litro'),
                  ),
                  TextField(
                      controller: GLController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado2 = (double.parse(GLController.text)) * (1000);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado2 L"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Onza líquida estadounidense a Litro'),
                  ),
                  TextField(
                      controller: OLController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado3 = (double.parse(OLController.text)) / (33.814);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado3 L"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  ListTile(
                    leading: Icon(Icons.wb_sunny),
                    title: Text('Pie cúbico a Litro'),
                  ),
                  TextField(
                      controller: PLController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                          border: OutlineInputBorder()
                      )
                  ),
                  ButtonTheme.bar( // make buttons use the appropriate styles for cards
                    child: ButtonBar(
                      children: <Widget>[
                        FlatButton(
                          child: const Text('Convertir'),
                          onPressed: () {
                            resultado4 = (double.parse(PLController.text)) * (28.317);
                            return showDialog(
                                context: context,
                                builder: (context){ return AlertDialog(content: Text("Resultado : $resultado4 L"));
                                }
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        )
    );
  }
}