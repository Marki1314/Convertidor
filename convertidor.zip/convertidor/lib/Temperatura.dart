import 'package:flutter/material.dart';

class Temperatura extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return TemperaturaState();
  }
}

class TemperaturaState extends State<Temperatura>{

  TextEditingController CFController = TextEditingController();
  TextEditingController FCController = TextEditingController();
  TextEditingController CKController = TextEditingController();
  TextEditingController KCController = TextEditingController();

  double resultado;
  double resultado2;
  double resultado3;
  double resultado4;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(

      appBar: AppBar(
        title: Text('TEMPERATURA'),
      ),
      body: ListView(
        children: <Widget>[
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ListTile(
                  leading: Icon(Icons.wb_sunny),
                  title: Text('Centrigrados a Fahrenheit'),
                  //subtitle: Text('Music by Julie Gable. Lyrics by Sidney Stein.'),
                ),
                TextField(
                    controller: CFController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        border: OutlineInputBorder()
                    )
                ),
                ButtonTheme.bar( // make buttons use the appropriate styles for cards
                  child: ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        child: const Text('Convertir'),
                        onPressed: () {
                          resultado = double.parse(CFController.text) * 1.8 + 32 ;
                          return showDialog(
                              context: context,
                              builder: (context){ return AlertDialog(content: Text("Resultado : $resultado °F"));
                              }
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ListTile(
                  leading: Icon(Icons.wb_sunny),
                  title: Text('Fahrenheit a Centrigrados'),
                ),
                TextField(
                    controller: FCController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        border: OutlineInputBorder()
                    )
                ),
                ButtonTheme.bar( // make buttons use the appropriate styles for cards
                  child: ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        child: const Text('Convertir'),
                        onPressed: () {
                          resultado2 = (double.parse(FCController.text) * (9/5)) + 32;
                          return showDialog(
                              context: context,
                              builder: (context){ return AlertDialog(content: Text("Resultado : $resultado2 °C"));
                            }
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ListTile(
                  leading: Icon(Icons.wb_sunny),
                  title: Text('Centrigrados a Kelvin'),
                ),
                TextField(
                    controller: CKController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        border: OutlineInputBorder()
                    )
                ),
                ButtonTheme.bar( // make buttons use the appropriate styles for cards
                  child: ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        child: const Text('Convertir'),
                        onPressed: () {
                          resultado3 = double.parse(CKController.text) + 273.15;
                          return showDialog(
                              context: context,
                              builder: (context){ return AlertDialog(content: Text("Resultado : $resultado3 °K"));
                              }
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Card(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ListTile(
                  leading: Icon(Icons.wb_sunny),
                  title: Text('Kelvin a Centrigrados'),
                ),
                TextField(
                    controller: KCController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                        border: OutlineInputBorder()
                    )
                ),
                ButtonTheme.bar( // make buttons use the appropriate styles for cards
                  child: ButtonBar(
                    children: <Widget>[
                      FlatButton(
                        child: const Text('Convertir'),
                        onPressed: () {
                          resultado4 = (double.parse(KCController.text))-(273.15);
                          return showDialog(
                              context: context,
                              builder: (context){ return AlertDialog(content: Text("Resultado : $resultado4 °C"));
                              }
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      )
    );
  }
}